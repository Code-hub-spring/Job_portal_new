import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a557b866"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=a557b866"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=303b1ca1"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=f0a3e36d";
import "/node_modules/.vite/deps/core-js.js?v=8e19e3ac";
import App from "/src/App.js?t=1745135141885";
import store from "/src/store.js";
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(Provider, { store, children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/bhagyag/Downloads/coreui-free-react-admin-template/UI/src/index.js",
    lineNumber: 11,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/bhagyag/Downloads/coreui-free-react-admin-template/UI/src/index.js",
    lineNumber: 10,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCAnY29yZS1qcydcblxuaW1wb3J0IEFwcCBmcm9tICcuL0FwcCdcbmltcG9ydCBzdG9yZSBmcm9tICcuL3N0b3JlJ1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpLnJlbmRlcihcbiAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgPEFwcCAvPlxuICA8L1Byb3ZpZGVyPixcbilcbiJdLCJtYXBwaW5ncyI6IkFBVUk7QUFWSixPQUFPLFdBQVc7QUFDbEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTztBQUVQLE9BQU8sU0FBUztBQUNoQixPQUFPLFdBQVc7QUFFbEIsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFDLEVBQUU7QUFBQSxFQUMxQyx1QkFBQyxZQUFTLE9BQ1IsaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUssS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFDRjsiLCJuYW1lcyI6W119